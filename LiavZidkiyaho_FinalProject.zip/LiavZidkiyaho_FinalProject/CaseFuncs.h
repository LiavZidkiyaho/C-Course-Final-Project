#ifndef CaseFuncs
#define CaseFuncs

#include "linkedList.h"

void case1_func_AddFrame(FrameNode** head);
void case2_func_RemoveFrame(FrameNode** head);
void case3_func_ChangeIndex(FrameNode** head);
void case4_func_ChangeDuration(FrameNode** head);
void case5_func_ChangeAllDurations(FrameNode** head);

#endif