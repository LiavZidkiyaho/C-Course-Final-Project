#ifndef ScreenOutput
#define ScreenOutput

#include "linkedList.h"

void printFrameList(FrameNode* head);
void printCommandMenu();
void printNewOrLoadGIFMenu();

#endif